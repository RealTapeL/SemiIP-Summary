# 欢迎来到 MinerU 项目列表

## 项目列表

- 已兼容2.0版本的项目列表
  - [multi_gpu_v2](./multi_gpu_v2/README_zh.md): 基于 LitServe 的多 GPU 并行处理

- 未兼容2.0版本的项目列表
  - [mcp](./mcp/README.md): 基于官方api的mcp server
